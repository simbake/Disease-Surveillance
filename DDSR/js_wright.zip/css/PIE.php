<?php
header( 'Content-type: text/x-component' );
include( '../wright/js/PIE.htc' );
?>